# -*- coding: utf-8 -*-

from distutils.core import setup

setup(name = "genpassword",
      version = "0.1.1",
      author = "le087",
      author_email = "mak.tomilov@gmail.com",
      Liciense = "GPL", 
      description = "Generator passwords as human words",
      py_modules = ['genpassword'],
      scripts = ['gen-pass.py'],
      )
